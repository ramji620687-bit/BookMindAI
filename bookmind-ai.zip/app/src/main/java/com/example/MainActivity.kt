package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.example.ui.components.BookMindBottomNavBar
import com.example.ui.components.BookMindTopHeader
import com.example.ui.navigation.Screen
import com.example.ui.screens.aitutor.AiTutorScreen
import com.example.ui.screens.bookmarks.BookmarksScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.library.LibraryScreen
import com.example.ui.screens.notes.NotesScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.progress.ProgressScreen
import com.example.ui.screens.reader.ReaderScreen
import com.example.ui.screens.scanner.ScannerScreen
import com.example.ui.theme.BookMindTheme
import com.example.ui.viewmodels.BookMindViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            BookMindApp()
        }
    }
}

@Composable
fun BookMindApp(viewModel: BookMindViewModel = viewModel()) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Home.route

    // ViewModel State
    val allBooks by viewModel.allBooks.collectAsStateWithLifecycle()
    val currentBook by viewModel.currentBook.collectAsStateWithLifecycle()
    val currentPages by viewModel.currentPages.collectAsStateWithLifecycle()
    val allNotes by viewModel.allNotes.collectAsStateWithLifecycle()
    val allBookmarks by viewModel.allBookmarks.collectAsStateWithLifecycle()
    val allSessions by viewModel.allSessions.collectAsStateWithLifecycle()
    val chatMessages by viewModel.currentChat.collectAsStateWithLifecycle()
    val isAiLoading by viewModel.isAiLoading.collectAsStateWithLifecycle()

    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()

    val scanStep by viewModel.scanStep.collectAsStateWithLifecycle()
    val scannedTitle by viewModel.scannedTitle.collectAsStateWithLifecycle()
    val scannedAuthor by viewModel.scannedAuthor.collectAsStateWithLifecycle()
    val scannedCategory by viewModel.scannedCategory.collectAsStateWithLifecycle()
    val scannedOcrText by viewModel.scannedOcrText.collectAsStateWithLifecycle()

    // Show top header and bottom nav bar only for primary screens
    val isPrimaryScreen = currentRoute in listOf(
        Screen.Home.route,
        Screen.Library.route,
        Screen.Scan.route,
        Screen.AiTutor.route,
        Screen.Profile.route
    )

    BookMindTheme {
        Scaffold(
            topBar = {
                if (isPrimaryScreen) {
                    BookMindTopHeader(
                        userName = "Alex Rivera",
                        onNotificationClick = { /* Notification action */ },
                        onProfileClick = { navController.navigate(Screen.Profile.route) }
                    )
                }
            },
            bottomBar = {
                if (isPrimaryScreen) {
                    BookMindBottomNavBar(
                        currentRoute = currentRoute,
                        onNavigate = { route ->
                            navController.navigate(route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        onQuickScan = { navController.navigate(Screen.Scan.route) },
                        onQuickAi = { navController.navigate(Screen.AiTutor.route) },
                        onQuickNote = { navController.navigate(Screen.Notes.route) }
                    )
                }
            },
            modifier = Modifier.fillMaxSize()
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = Screen.Home.route,
                modifier = Modifier.padding(innerPadding)
            ) {
                // Home Screen
                composable(Screen.Home.route) {
                    HomeScreen(
                        currentBook = currentBook,
                        recentBooks = allBooks,
                        streakDays = viewModel.currentStreakDays,
                        todayMinutes = 45,
                        goalMinutes = viewModel.dailyGoalMinutes,
                        onResumeReading = { bookId ->
                            viewModel.selectBook(bookId)
                            val page = currentBook?.currentPage ?: 1
                            navController.navigate(Screen.Reader.createRoute(bookId, page))
                        },
                        onViewBookDetails = { bookId ->
                            viewModel.selectBook(bookId)
                            navController.navigate(Screen.Library.route)
                        },
                        onViewStats = { navController.navigate(Screen.Progress.route) },
                        onQuickAction = { action ->
                            when (action) {
                                "scan" -> navController.navigate(Screen.Scan.route)
                                "ai" -> navController.navigate(Screen.AiTutor.route)
                                "notes" -> navController.navigate(Screen.Notes.route)
                            }
                        }
                    )
                }

                // Library Screen
                composable(Screen.Library.route) {
                    LibraryScreen(
                        books = allBooks,
                        searchQuery = searchQuery,
                        onSearchQueryChange = { viewModel.setSearchQuery(it) },
                        selectedCategory = selectedCategory,
                        onCategorySelect = { viewModel.setSelectedCategory(it) },
                        onBookClick = { bookId ->
                            viewModel.selectBook(bookId)
                            navController.navigate(Screen.Reader.createRoute(bookId, 1))
                        },
                        onToggleFavorite = { book -> viewModel.toggleFavorite(book) }
                    )
                }

                // Scanner Screen
                composable(Screen.Scan.route) {
                    ScannerScreen(
                        currentStep = scanStep,
                        onSetStep = { viewModel.setScanStep(it) },
                        scannedTitle = scannedTitle,
                        scannedAuthor = scannedAuthor,
                        scannedCategory = scannedCategory,
                        scannedOcrText = scannedOcrText,
                        onSetDetails = { title, author, category, ocrText ->
                            viewModel.setScannedDetails(title, author, category, ocrText)
                        },
                        onSaveBook = { viewModel.saveScannedBook() }
                    )
                }

                // AI Tutor Screen
                composable(Screen.AiTutor.route) {
                    AiTutorScreen(
                        currentBook = currentBook,
                        chatMessages = chatMessages,
                        isLoading = isAiLoading,
                        onSendMessage = { prompt, mode, pageContext ->
                            viewModel.sendAiPrompt(prompt, mode, pageContext)
                        }
                    )
                }

                // Profile Screen
                composable(Screen.Profile.route) {
                    ProfileScreen(
                        onNavigateToBookmarks = { navController.navigate(Screen.Bookmarks.route) },
                        onNavigateToNotes = { navController.navigate(Screen.Notes.route) },
                        onNavigateToProgress = { navController.navigate(Screen.Progress.route) }
                    )
                }

                // Reader Screen
                composable(
                    route = Screen.Reader.route,
                    arguments = listOf(
                        navArgument("bookId") { type = NavType.LongType },
                        navArgument("pageNumber") { type = NavType.IntType }
                    )
                ) { backStackEntry ->
                    val bookId = backStackEntry.arguments?.getLong("bookId") ?: 1L
                    val pageNumber = backStackEntry.arguments?.getInt("pageNumber") ?: 1

                    LaunchedEffect(bookId) {
                        viewModel.selectBook(bookId)
                    }

                    ReaderScreen(
                        book = currentBook,
                        pages = currentPages,
                        onBack = { navController.popBackStack() },
                        onPageChange = { newPage ->
                            viewModel.updateReadingPage(bookId, newPage)
                        },
                        onBookmarkToggle = {
                            viewModel.addBookmark()
                        },
                        onOpenAiSheet = { mode ->
                            navController.navigate(Screen.AiTutor.route)
                        },
                        onAddNote = {
                            navController.navigate(Screen.Notes.route)
                        }
                    )
                }

                // Notes Screen
                composable(Screen.Notes.route) {
                    NotesScreen(
                        notes = allNotes,
                        onAddNote = { title, content, type ->
                            viewModel.addNote(title, content, type)
                        },
                        onDeleteNote = { note ->
                            viewModel.deleteNote(note)
                        }
                    )
                }

                // Bookmarks Screen
                composable(Screen.Bookmarks.route) {
                    BookmarksScreen(
                        bookmarks = allBookmarks,
                        onSelectBookmark = { bookId, pageNumber ->
                            viewModel.selectBook(bookId)
                            navController.navigate(Screen.Reader.createRoute(bookId, pageNumber))
                        },
                        onDeleteBookmark = { bookmark ->
                            viewModel.deleteBookmark(bookmark)
                        }
                    )
                }

                // Progress Screen
                composable(Screen.Progress.route) {
                    ProgressScreen(
                        sessions = allSessions,
                        streakDays = viewModel.currentStreakDays
                    )
                }
            }
        }
    }
}
