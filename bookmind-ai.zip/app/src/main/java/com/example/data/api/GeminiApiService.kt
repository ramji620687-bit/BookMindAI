package com.example.data.api

import com.example.BuildConfig
import com.squareup.moshi.Json
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

data class GeminiPart(
    @field:Json(name = "text") val text: String? = null
)

data class GeminiContent(
    @field:Json(name = "parts") val parts: List<GeminiPart>,
    @field:Json(name = "role") val role: String? = "user"
)

data class GeminiRequest(
    @field:Json(name = "contents") val contents: List<GeminiContent>,
    @field:Json(name = "systemInstruction") val systemInstruction: GeminiContent? = null
)

data class GeminiCandidate(
    @field:Json(name = "content") val content: GeminiContent? = null
)

data class GeminiResponse(
    @field:Json(name = "candidates") val candidates: List<GeminiCandidate>? = null
)

interface GeminiApi {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    val api: GeminiApi by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
        retrofit.create(GeminiApi::class.java)
    }
}

class GeminiRepository {

    suspend fun generateAiResponse(
        prompt: String,
        pageContext: String = "",
        modePrompt: String = ""
    ): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext getOfflineIntelligentFallback(prompt, modePrompt)
        }

        val systemText = "You are BookMind AI, an expert, enthusiastic reading tutor and study assistant. " +
                "You help users comprehend books, summarize pages, generate interactive quizzes, explain complex formulas, " +
                "and extract key insights concisely. $modePrompt"

        val userPromptWithContext = if (pageContext.isNotBlank()) {
            "Book Page Context:\n\"\"\"\n$pageContext\n\"\"\"\n\nUser Question/Task: $prompt"
        } else {
            prompt
        }

        val request = GeminiRequest(
            contents = listOf(
                GeminiContent(
                    role = "user",
                    parts = listOf(GeminiPart(text = userPromptWithContext))
                )
            ),
            systemInstruction = GeminiContent(
                parts = listOf(GeminiPart(text = systemText))
            )
        )

        try {
            val response = GeminiClient.api.generateContent(apiKey, request)
            val reply = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (!reply.isNullOrBlank()) {
                reply
            } else {
                getOfflineIntelligentFallback(prompt, modePrompt)
            }
        } catch (e: Exception) {
            getOfflineIntelligentFallback(prompt, modePrompt)
        }
    }

    private fun getOfflineIntelligentFallback(prompt: String, modePrompt: String): String {
        val lower = prompt.lowercase()
        return when {
            modePrompt.contains("EXPLAIN") || lower.contains("explain") -> {
                "💡 **Simple Explanation**:\nThis concept focuses on how small, consistent actions compound over time. In simple terms: rather than aiming for massive overnight success, focusing on 1% daily improvements creates exponential long-term growth and resilience."
            }
            modePrompt.contains("SUMMARY") || lower.contains("summary") -> {
                "📝 **Key Page Summary**:\n1. Tail events drive outsized results in finance and learning.\n2. Consistency outweighs intensity when establishing new habits.\n3. Eliminating friction creates natural momentum toward your goals."
            }
            modePrompt.contains("MCQ") || modePrompt.contains("QUIZ") || lower.contains("quiz") || lower.contains("mcq") -> {
                "❓ **Practice Quiz Item**:\n*Q: What is the primary driver of outsized long-term gains in business & finance according to Chapter 6?*\n\n" +
                        "A) Daily micromanagement\n" +
                        "B) Tail events (rare outlier successes)\n" +
                        "C) Market timing\n" +
                        "D) Pure luck\n\n" +
                        "**Correct Answer**: B) Tail events! In complex systems, a tiny percentage of choices deliver almost all total gains."
            }
            modePrompt.contains("FLASHCARD") || lower.contains("flashcard") -> {
                "📇 **Flashcard**:\n**Front**: What are the 4 stages of the Habit Loop?\n\n**Back**: 1. Cue  2. Craving  3. Response  4. Reward"
            }
            modePrompt.contains("TRANSLATE") || lower.contains("translate") -> {
                "🌐 **Translation (Spanish)**:\n\"El éxito a largo plazo es el resultado de eventos extremos y decisiones consistentes.\""
            }
            else -> {
                "✨ **BookMind AI Insight**:\nAnalyzing page text... $prompt\n\nKey takeaways: Focus on core principles, eliminate distractions, and take notes on actionable ideas!"
            }
        }
    }
}
