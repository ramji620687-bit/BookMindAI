package com.example.data.repository

import com.example.data.db.*
import kotlinx.coroutines.flow.Flow

class BookMindRepository(private val dao: BookMindDao) {

    val allBooks: Flow<List<BookEntity>> = dao.getAllBooks()
    val favoriteBooks: Flow<List<BookEntity>> = dao.getFavoriteBooks()
    val allNotes: Flow<List<NoteEntity>> = dao.getAllNotes()
    val allBookmarks: Flow<List<BookmarkEntity>> = dao.getAllBookmarks()
    val allSessions: Flow<List<ReadingSessionEntity>> = dao.getAllSessions()

    fun getBookFlow(bookId: Long): Flow<BookEntity?> = dao.getBookByIdFlow(bookId)
    suspend fun getBook(bookId: Long): BookEntity? = dao.getBookById(bookId)

    fun getChapters(bookId: Long): Flow<List<ChapterEntity>> = dao.getChaptersForBook(bookId)
    fun getPages(bookId: Long): Flow<List<PageEntity>> = dao.getPagesForBook(bookId)
    suspend fun getPage(bookId: Long, pageNumber: Int): PageEntity? = dao.getPage(bookId, pageNumber)

    fun getNotesForBook(bookId: Long): Flow<List<NoteEntity>> = dao.getNotesForBook(bookId)
    fun getChatForBook(bookId: Long): Flow<List<ChatMessageEntity>> = dao.getChatForBook(bookId)

    suspend fun insertBook(book: BookEntity): Long = dao.insertBook(book)
    suspend fun updateBook(book: BookEntity) = dao.updateBook(book)
    suspend fun deleteBook(book: BookEntity) = dao.deleteBook(book)
    suspend fun updateProgress(bookId: Long, pageNumber: Int) = dao.updateReadingProgress(bookId, pageNumber)

    suspend fun insertPage(page: PageEntity): Long = dao.insertPage(page)
    suspend fun setPageBookmarked(pageId: Long, isBookmarked: Boolean) = dao.setPageBookmarked(pageId, isBookmarked)

    suspend fun insertNote(note: NoteEntity): Long = dao.insertNote(note)
    suspend fun deleteNote(note: NoteEntity) = dao.deleteNote(note)

    suspend fun insertBookmark(bookmark: BookmarkEntity): Long = dao.insertBookmark(bookmark)
    suspend fun deleteBookmark(bookmark: BookmarkEntity) = dao.deleteBookmark(bookmark)

    suspend fun insertChatMessage(message: ChatMessageEntity): Long = dao.insertChatMessage(message)
    suspend fun recordReadingSession(session: ReadingSessionEntity) = dao.insertSession(session)
}
