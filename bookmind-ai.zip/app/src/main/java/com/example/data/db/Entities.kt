package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "books")
data class BookEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val author: String,
    val totalPages: Int,
    val currentPage: Int = 1,
    val coverGradientIndex: Int = 0,
    val category: String = "Non-Fiction",
    val chapterCount: Int = 10,
    val summary: String = "",
    val dateAdded: Long = System.currentTimeMillis(),
    val lastReadTimestamp: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false
)

@Entity(tableName = "chapters")
data class ChapterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long,
    val chapterNumber: Int,
    val title: String,
    val startPage: Int,
    val endPage: Int
)

@Entity(tableName = "pages")
data class PageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long,
    val chapterId: Long = 0,
    val pageNumber: Int,
    val rawText: String,
    val ocrEnhancedText: String = "",
    val imagePath: String = "",
    val isBookmarked: Boolean = false
)

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long,
    val bookTitle: String = "",
    val pageNumber: Int,
    val title: String,
    val content: String,
    val noteType: String = "TEXT", // TEXT, VOICE, DRAWING
    val createdAt: Long = System.currentTimeMillis(),
    val tags: String = "General"
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long,
    val bookTitle: String = "",
    val pageNumber: Int,
    val chapterTitle: String = "",
    val noteSnippet: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long,
    val pageNumber: Int,
    val sender: String, // "USER" or "AI"
    val text: String,
    val mode: String = "GENERAL", // GENERAL, EXPLAIN, SUMMARY, MCQ, QUIZ, TEACHER
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "reading_sessions")
data class ReadingSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long,
    val dateString: String, // YYYY-MM-DD
    val minutesRead: Int,
    val pagesRead: Int,
    val timestamp: Long = System.currentTimeMillis()
)
