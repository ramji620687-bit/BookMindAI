package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        BookEntity::class,
        ChapterEntity::class,
        PageEntity::class,
        NoteEntity::class,
        BookmarkEntity::class,
        ChatMessageEntity::class,
        ReadingSessionEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class BookMindDatabase : RoomDatabase() {

    abstract fun bookMindDao(): BookMindDao

    companion object {
        @Volatile
        private var INSTANCE: BookMindDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): BookMindDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BookMindDatabase::class.java,
                    "bookmind_database"
                )
                    .addCallback(BookMindDatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class BookMindDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {

        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateDatabase(database.bookMindDao())
                }
            }
        }

        suspend fun populateDatabase(dao: BookMindDao) {
            // Book 1: The Psychology of Money
            val book1Id = dao.insertBook(
                BookEntity(
                    title = "The Psychology of Money",
                    author = "Morgan Housel",
                    totalPages = 252,
                    currentPage = 125,
                    coverGradientIndex = 0, // Blue-Indigo
                    category = "Finance",
                    chapterCount = 20,
                    summary = "Timeless lessons on wealth, greed, and happiness. Morgan Housel teaches us that doing well with money has a little to do with how smart you are and a lot to do with how you behave.",
                    isFavorite = true
                )
            )

            dao.insertChapters(
                listOf(
                    ChapterEntity(bookId = book1Id, chapterNumber = 1, title = "No One's Crazy", startPage = 1, endPage = 18),
                    ChapterEntity(bookId = book1Id, chapterNumber = 2, title = "Luck & Risk", startPage = 19, endPage = 35),
                    ChapterEntity(bookId = book1Id, chapterNumber = 3, title = "Never Enough", startPage = 36, endPage = 52),
                    ChapterEntity(bookId = book1Id, chapterNumber = 4, title = "Confounding Compounding", startPage = 53, endPage = 70),
                    ChapterEntity(bookId = book1Id, chapterNumber = 5, title = "Getting Wealthy vs. Staying Wealthy", startPage = 71, endPage = 92),
                    ChapterEntity(bookId = book1Id, chapterNumber = 6, title = "Tails, You Win", startPage = 93, endPage = 125)
                )
            )

            dao.insertPage(
                PageEntity(
                    bookId = book1Id,
                    pageNumber = 125,
                    rawText = """
Chapter 6: Tails, You Win

Anything that is huge, profitable, famous, or influential is the result of a tail event—an item in the far right distribution curve.
In business and finance, most things fail. The best venture capitalists expect that 80% of their investments will be duds.
Warren Buffett has owned 400 to 500 stocks in his lifetime. He made most of his money on 10 of them. Charlie Munger told me: "If you remove just a few of Berkshire's top investments, its long-term track record is pretty average."

Key takeaway: You can be wrong half the time and still make a fortune. It is not about whether you are right or wrong, but how much money you make when you are right and how much you lose when you are wrong.
                    """.trimIndent(),
                    ocrEnhancedText = "Tails drive everything in economics and investing. A tiny percentage of decisions deliver 99% of total gains.",
                    isBookmarked = true
                )
            )

            // Book 2: Atomic Habits
            val book2Id = dao.insertBook(
                BookEntity(
                    title = "Atomic Habits",
                    author = "James Clear",
                    totalPages = 320,
                    currentPage = 88,
                    coverGradientIndex = 1, // Emerald-Teal
                    category = "Self-Improvement",
                    chapterCount = 18,
                    summary = "An easy and proven way to build good habits and break bad ones. James Clear reveals how tiny changes can transform your life.",
                    isFavorite = true
                )
            )

            dao.insertChapters(
                listOf(
                    ChapterEntity(bookId = book2Id, chapterNumber = 1, title = "The Surprising Power of Atomic Habits", startPage = 1, endPage = 25),
                    ChapterEntity(bookId = book2Id, chapterNumber = 2, title = "How Your Habits Shape Your Identity", startPage = 26, endPage = 50),
                    ChapterEntity(bookId = book2Id, chapterNumber = 3, title = "How to Build Better Habits in 4 Simple Steps", startPage = 51, endPage = 88)
                )
            )

            dao.insertPage(
                PageEntity(
                    bookId = book2Id,
                    pageNumber = 88,
                    rawText = """
The 1st Law of Behavior Change: Make It Obvious.

The human brain is a prediction machine. It is continuously taking in your surroundings and analyzing the information it encounters.
When you repeat a behavior, you are casting a vote for that type of identity.
The habit loop consists of four steps: Cue, Craving, Response, and Reward.
If a behavior lacks any of these four stages, it will not become a habit. Reduce friction for good habits, increase friction for bad ones.
                    """.trimIndent(),
                    ocrEnhancedText = "The 4 steps of the Habit Loop: Cue, Craving, Response, Reward.",
                    isBookmarked = false
                )
            )

            // Book 3: Clean Code
            val book3Id = dao.insertBook(
                BookEntity(
                    title = "Clean Code",
                    author = "Robert C. Martin",
                    totalPages = 464,
                    currentPage = 42,
                    coverGradientIndex = 2, // Amber-Orange
                    category = "Technology",
                    chapterCount = 17,
                    summary = "A Handbook of Agile Software Craftsmanship. Even bad code can function. But if code isn't clean, it can bring a development organization to its knees.",
                    isFavorite = false
                )
            )

            dao.insertChapters(
                listOf(
                    ChapterEntity(bookId = book3Id, chapterNumber = 1, title = "Clean Code", startPage = 1, endPage = 16),
                    ChapterEntity(bookId = book3Id, chapterNumber = 2, title = "Meaningful Names", startPage = 17, endPage = 34),
                    ChapterEntity(bookId = book3Id, chapterNumber = 3, title = "Functions", startPage = 35, endPage = 60)
                )
            )

            dao.insertPage(
                PageEntity(
                    bookId = book3Id,
                    pageNumber = 42,
                    rawText = """
Chapter 3: Functions

The first rule of functions is that they should be small. The second rule of functions is that they should be smaller than that.
Functions should do one thing. They should do it well. They should do it only.
Use descriptive names. Don't be afraid to make a name long. A long descriptive name is better than a short enigmatic name.
Side effects are lies. Your function promises to do one thing, but it also does other hidden things.
                    """.trimIndent(),
                    ocrEnhancedText = "Rule of Functions: Small, single-responsibility, clear descriptive naming, no side effects.",
                    isBookmarked = true
                )
            )

            // Book 4: Deep Work
            val book4Id = dao.insertBook(
                BookEntity(
                    title = "Deep Work",
                    author = "Cal Newport",
                    totalPages = 304,
                    currentPage = 15,
                    coverGradientIndex = 3, // Rose-Red
                    category = "Productivity",
                    chapterCount = 9,
                    summary = "Rules for Focused Success in a Distracted World. Deep work is the ability to focus without distraction on a demanding task.",
                    isFavorite = false
                )
            )

            // Seed initial notes & bookmarks
            dao.insertNote(
                NoteEntity(
                    bookId = book1Id,
                    bookTitle = "The Psychology of Money",
                    pageNumber = 125,
                    title = "Tails Drive Everything",
                    content = "In investing and business, 90% of outcomes stem from a few outlier decisions. Expect high failure rate in individual experiments.",
                    noteType = "TEXT",
                    tags = "Investing"
                )
            )

            dao.insertBookmark(
                BookmarkEntity(
                    bookId = book1Id,
                    bookTitle = "The Psychology of Money",
                    pageNumber = 125,
                    chapterTitle = "Tails, You Win",
                    noteSnippet = "You can be wrong half the time and still make a fortune."
                )
            )

            dao.insertChatMessage(
                ChatMessageEntity(
                    bookId = book1Id,
                    pageNumber = 125,
                    sender = "AI",
                    text = "Welcome to BookMind AI Tutor! I have analyzed Page 125 of 'The Psychology of Money'. Feel free to ask me to explain concepts, generate a summary, or create a quiz!",
                    mode = "GENERAL"
                )
            )

            // Seed initial sessions
            dao.insertSession(ReadingSessionEntity(bookId = book1Id, dateString = "2026-07-28", minutesRead = 45, pagesRead = 18))
            dao.insertSession(ReadingSessionEntity(bookId = book2Id, dateString = "2026-07-29", minutesRead = 30, pagesRead = 12))
        }
    }
}
