package com.example.ui.screens.progress

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.ReadingSessionEntity
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.PrimaryBlue

@Composable
fun ProgressScreen(
    sessions: List<ReadingSessionEntity>,
    streakDays: Int = 12
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        Text(
            text = "Reading Statistics",
            fontWeight = FontWeight.ExtraBold,
            fontSize = 24.sp,
            modifier = Modifier.padding(top = 12.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Tab Row (Weekly vs Monthly)
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            indicator = {},
            modifier = Modifier
                .clip(CircleShape)
                .padding(4.dp)
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Weekly Overview", fontWeight = FontWeight.Bold) },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(if (selectedTab == 0) PrimaryBlue else Color.Transparent)
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Monthly Goal", fontWeight = FontWeight.Bold) },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(if (selectedTab == 1) PrimaryBlue else Color.Transparent)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Custom Weekly Progress Bar Chart
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Reading Time (Minutes per Day)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Canvas Bar Chart
                val days = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
                val values = listOf(30f, 45f, 60f, 25f, 50f, 40f, 65f)

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                ) {
                    val barWidth = 28.dp.toPx()
                    val gap = (size.width - (barWidth * days.size)) / (days.size + 1)
                    val maxVal = 70f

                    values.forEachIndexed { index, value ->
                        val x = gap + index * (barWidth + gap)
                        val barHeight = (value / maxVal) * size.height
                        val y = size.height - barHeight

                        drawRoundRect(
                            color = if (index == 6) AccentAmber else PrimaryBlue,
                            topLeft = Offset(x, y),
                            size = Size(barWidth, barHeight),
                            cornerRadius = CornerRadius(12f, 12f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    days.forEach { day ->
                        Text(
                            text = day,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Badges and Achievements
        Text(
            text = "Achievements & Badges",
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            AchievementItem(
                title = "12-Day Streak Master",
                desc = "Read at least 20 minutes every day for 12 days straight.",
                icon = "⚡",
                isUnlocked = true
            )
            AchievementItem(
                title = "AI Scholar",
                desc = "Asked 25 AI Tutor questions on book chapters.",
                icon = "🎓",
                isUnlocked = true
            )
            AchievementItem(
                title = "Book Mind Scanner",
                desc = "Scanned 10 book pages via camera OCR.",
                icon = "📷",
                isUnlocked = true
            )
        }
    }
}

@Composable
fun AchievementItem(title: String, desc: String, icon: String, isUnlocked: Boolean) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("achievement_$title")
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = icon, fontSize = 32.sp)

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Text(
                    text = desc,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Icon(
                imageVector = Icons.Default.MilitaryTech,
                contentDescription = null,
                tint = if (isUnlocked) AccentAmber else Color.Gray,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}


