package com.example.ui.screens.reader

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.BookEntity
import com.example.data.db.PageEntity
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.PrimaryBlue

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    book: BookEntity?,
    pages: List<PageEntity>,
    onBack: () -> Unit,
    onPageChange: (Int) -> Unit,
    onBookmarkToggle: () -> Unit,
    onOpenAiSheet: (String) -> Unit,
    onAddNote: () -> Unit
) {
    var fontScale by remember { mutableFloatStateOf(16f) }
    var isVoiceActive by remember { mutableStateOf(false) }
    var translatedText by remember { mutableStateOf<String?>(null) }
    var isSearchVisible by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    val currentPageNumber = book?.currentPage ?: 1
    val currentPage = pages.find { it.pageNumber == currentPageNumber } ?: PageEntity(
        bookId = book?.id ?: 1,
        pageNumber = currentPageNumber,
        rawText = "Chapter ${currentPageNumber / 20 + 1}\n\n" +
                "Consistency and compounding remain the cornerstone of enduring success. When analyzing complex systems, focus on the underlying mental models rather than transient surface noise.",
        ocrEnhancedText = "Core concept: Long-term compounding and mental models."
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = book?.title ?: "Book Reader",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            maxLines = 1
                        )
                        Text(
                            text = "Page $currentPageNumber of ${book?.totalPages ?: 200}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onBookmarkToggle) {
                        Icon(
                            imageVector = if (currentPage.isBookmarked) Icons.Default.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = "Bookmark",
                            tint = if (currentPage.isBookmarked) AccentAmber else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = { isSearchVisible = !isSearchVisible }) {
                        Icon(Icons.Default.Search, contentDescription = "Search in Book")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            // Reader Bottom Toolbar
            Surface(
                tonalElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("reader_bottom_toolbar")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ReaderToolButton(icon = Icons.Default.Highlight, label = "Highlight", onClick = { /* Highlight */ })
                    ReaderToolButton(icon = Icons.Default.EditNote, label = "Notes", onClick = onAddNote)
                    ReaderToolButton(icon = Icons.Default.AutoAwesome, label = "AI Tutor", tint = AccentAmber, onClick = { onOpenAiSheet("GENERAL") })
                    ReaderToolButton(
                        icon = Icons.Default.Translate,
                        label = "Translate",
                        onClick = {
                            translatedText = "Español: La consistencia y la acumulación siguen siendo la piedra angular del éxito duradero."
                        }
                    )
                    ReaderToolButton(
                        icon = if (isVoiceActive) Icons.Default.VolumeUp else Icons.Default.RecordVoiceOver,
                        label = if (isVoiceActive) "Speaking..." else "Listen",
                        tint = if (isVoiceActive) PrimaryBlue else MaterialTheme.colorScheme.onSurface,
                        onClick = { isVoiceActive = !isVoiceActive }
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Search in book overlay
            AnimatedVisibility(visible = isSearchVisible) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search words in book...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }

            // Page Navigation Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = { if (currentPageNumber > 1) onPageChange(currentPageNumber - 1) },
                    enabled = currentPageNumber > 1
                ) {
                    Icon(Icons.Default.ChevronLeft, contentDescription = "Prev")
                    Text("Prev Page")
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { fontScale = (fontScale - 2f).coerceAtLeast(12f) }) {
                        Text("A-", fontWeight = FontWeight.Bold)
                    }
                    Text("${fontScale.toInt()} sp", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    IconButton(onClick = { fontScale = (fontScale + 2f).coerceAtMost(28f) }) {
                        Text("A+", fontWeight = FontWeight.Bold)
                    }
                }

                TextButton(
                    onClick = { if (currentPageNumber < (book?.totalPages ?: 200)) onPageChange(currentPageNumber + 1) },
                    enabled = currentPageNumber < (book?.totalPages ?: 200)
                ) {
                    Text("Next Page")
                    Icon(Icons.Default.ChevronRight, contentDescription = "Next")
                }
            }

            // Page Canvas
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Column {
                    Text(
                        text = currentPage.rawText,
                        fontSize = fontScale.sp,
                        lineHeight = (fontScale * 1.5).sp,
                        fontFamily = FontFamily.Serif,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    translatedText?.let { translation ->
                        Spacer(modifier = Modifier.height(20.dp))
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "🌐 AI Translation",
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryBlue,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = translation,
                                    fontSize = (fontScale - 2f).sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReaderToolButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color = MaterialTheme.colorScheme.onSurface,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Icon(imageVector = icon, contentDescription = label, tint = tint, modifier = Modifier.size(22.dp))
        Text(text = label, fontSize = 10.sp, fontWeight = FontWeight.Medium, color = tint)
    }
}
