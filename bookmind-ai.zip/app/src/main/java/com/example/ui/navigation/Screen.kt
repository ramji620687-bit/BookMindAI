package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val title: String, val selectedIcon: ImageVector, val unselectedIcon: ImageVector) {
    object Home : Screen("home", "Home", Icons.Filled.Home, Icons.Outlined.Home)
    object Library : Screen("library", "Library", Icons.Filled.MenuBook, Icons.Outlined.MenuBook)
    object Scan : Screen("scan", "Scan", Icons.Filled.CenterFocusWeak, Icons.Outlined.CenterFocusWeak)
    object AiTutor : Screen("ai_tutor", "AI Tutor", Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome)
    object Profile : Screen("profile", "Profile", Icons.Filled.Person, Icons.Outlined.Person)

    // Secondary routes
    object Reader : Screen("reader/{bookId}/{pageNumber}", "Reader", Icons.Filled.Book, Icons.Outlined.Book) {
        fun createRoute(bookId: Long, pageNumber: Int = 1) = "reader/$bookId/$pageNumber"
    }
    object Notes : Screen("notes", "Notes", Icons.Filled.EditNote, Icons.Outlined.EditNote)
    object Bookmarks : Screen("bookmarks", "Bookmarks", Icons.Filled.Bookmark, Icons.Outlined.BookmarkBorder)
    object Progress : Screen("progress", "Progress", Icons.Filled.Leaderboard, Icons.Outlined.Leaderboard)
}

val bottomNavItems = listOf(
    Screen.Home,
    Screen.Library,
    Screen.Scan,
    Screen.AiTutor,
    Screen.Profile
)
