package com.example.ui.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiRepository
import com.example.data.db.*
import com.example.data.repository.BookMindRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BookMindViewModel(application: Application) : AndroidViewModel(application) {

    private val db = BookMindDatabase.getDatabase(application, viewModelScope)
    private val repository = BookMindRepository(db.bookMindDao())
    private val geminiRepository = GeminiRepository()

    // State flows
    val allBooks = repository.allBooks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val favoriteBooks = repository.favoriteBooks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allNotes = repository.allNotes.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allBookmarks = repository.allBookmarks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allSessions = repository.allSessions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Book and Page
    private val _selectedBookId = MutableStateFlow<Long>(1L)
    val selectedBookId = _selectedBookId.asStateFlow()

    val currentBook: StateFlow<BookEntity?> = _selectedBookId.flatMapLatest { id ->
        repository.getBookFlow(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentChapters: StateFlow<List<ChapterEntity>> = _selectedBookId.flatMapLatest { id ->
        repository.getChapters(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentPages: StateFlow<List<PageEntity>> = _selectedBookId.flatMapLatest { id ->
        repository.getPages(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentChat: StateFlow<List<ChatMessageEntity>> = _selectedBookId.flatMapLatest { id ->
        repository.getChatForBook(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // AI Chat state
    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading = _isAiLoading.asStateFlow()

    // Scanning Workflow state
    private val _scannedTitle = MutableStateFlow("")
    val scannedTitle = _scannedTitle.asStateFlow()

    private val _scannedAuthor = MutableStateFlow("")
    val scannedAuthor = _scannedAuthor.asStateFlow()

    private val _scannedCategory = MutableStateFlow("Non-Fiction")
    val scannedCategory = _scannedCategory.asStateFlow()

    private val _scannedOcrText = MutableStateFlow("")
    val scannedOcrText = _scannedOcrText.asStateFlow()

    private val _scanStep = MutableStateFlow(0) // 0: Camera, 1: Crop, 2: Enhance, 3: OCR, 4: Details, 5: Complete
    val scanStep = _scanStep.asStateFlow()

    // Search and Filter State
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory = _selectedCategory.asStateFlow()

    // Daily Goals State
    val dailyGoalMinutes = 60
    val currentStreakDays = 12

    fun selectBook(bookId: Long) {
        _selectedBookId.value = bookId
    }

    fun updateReadingPage(bookId: Long, newPage: Int) {
        viewModelScope.launch {
            repository.updateProgress(bookId, newPage)
            // Record 5 mins of reading session
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            repository.recordReadingSession(
                ReadingSessionEntity(bookId = bookId, dateString = todayStr, minutesRead = 5, pagesRead = 1)
            )
        }
    }

    fun toggleFavorite(book: BookEntity) {
        viewModelScope.launch {
            repository.updateBook(book.copy(isFavorite = !book.isFavorite))
        }
    }

    // AI Chat Actions
    fun sendAiPrompt(prompt: String, mode: String = "GENERAL", pageContext: String = "") {
        val bookId = _selectedBookId.value
        viewModelScope.launch {
            // Save User message
            repository.insertChatMessage(
                ChatMessageEntity(bookId = bookId, pageNumber = currentBook.value?.currentPage ?: 1, sender = "USER", text = prompt, mode = mode)
            )

            _isAiLoading.value = true
            val aiResponseText = geminiRepository.generateAiResponse(
                prompt = prompt,
                pageContext = pageContext,
                modePrompt = "Mode: $mode."
            )
            _isAiLoading.value = false

            // Save AI message
            repository.insertChatMessage(
                ChatMessageEntity(bookId = bookId, pageNumber = currentBook.value?.currentPage ?: 1, sender = "AI", text = aiResponseText, mode = mode)
            )
        }
    }

    fun deleteNote(note: NoteEntity) {
        viewModelScope.launch {
            repository.deleteNote(note)
        }
    }

    fun deleteBookmark(bookmark: BookmarkEntity) {
        viewModelScope.launch {
            repository.deleteBookmark(bookmark)
        }
    }
    fun addNote(title: String, content: String, noteType: String = "TEXT", tags: String = "General") {
        val book = currentBook.value ?: return
        viewModelScope.launch {
            repository.insertNote(
                NoteEntity(
                    bookId = book.id,
                    bookTitle = book.title,
                    pageNumber = book.currentPage,
                    title = title,
                    content = content,
                    noteType = noteType,
                    tags = tags
                )
            )
        }
    }

    fun addBookmark(snippet: String = "") {
        val book = currentBook.value ?: return
        viewModelScope.launch {
            repository.insertBookmark(
                BookmarkEntity(
                    bookId = book.id,
                    bookTitle = book.title,
                    pageNumber = book.currentPage,
                    chapterTitle = "Chapter ${book.currentPage / 20 + 1}",
                    noteSnippet = snippet.ifEmpty { "Bookmarked Page ${book.currentPage}" }
                )
            )
        }
    }

    // Scanner Flow
    fun setScanStep(step: Int) {
        _scanStep.value = step
    }

    fun setScannedDetails(title: String, author: String, category: String, ocrText: String) {
        _scannedTitle.value = title
        _scannedAuthor.value = author
        _scannedCategory.value = category
        _scannedOcrText.value = ocrText
    }

    fun saveScannedBook() {
        viewModelScope.launch {
            val newBookId = repository.insertBook(
                BookEntity(
                    title = _scannedTitle.value.ifEmpty { "Scanned Volume ${allBooks.value.size + 1}" },
                    author = _scannedAuthor.value.ifEmpty { "Scanned Author" },
                    totalPages = 120,
                    currentPage = 1,
                    coverGradientIndex = (allBooks.value.size + 1) % 4,
                    category = _scannedCategory.value,
                    summary = _scannedOcrText.value
                )
            )
            // Add page 1
            repository.insertPage(
                PageEntity(
                    bookId = newBookId,
                    pageNumber = 1,
                    rawText = _scannedOcrText.value.ifEmpty { "Scanned page text content captured via camera OCR scanner." },
                    ocrEnhancedText = "Enhanced text ready for AI analysis."
                )
            )
            _scanStep.value = 5 // Complete
            _selectedBookId.value = newBookId
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(category: String) {
        _selectedCategory.value = category
    }
}
