package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Vibrant Palette Colors
val PrimaryBlue = Color(0xFF2563EB)
val PrimaryBlueLight = Color(0xFF3B82F6)
val PrimaryBlueDark = Color(0xFF1D4ED8)
val AccentAmber = Color(0xFFF59E0B)
val SuccessGreen = Color(0xFF22C55E)
val ErrorRed = Color(0xFFEF4444)

// Light Palette
val BackgroundLight = Color(0xFFFFFFFF)
val SurfaceLight = Color(0xFFF8FAFC)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)

// Dark Palette
val BackgroundDark = Color(0xFF121212)
val SurfaceDark = Color(0xFF1E1E1E)
val SurfaceVariantDark = Color(0xFF2D2D2D)
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
